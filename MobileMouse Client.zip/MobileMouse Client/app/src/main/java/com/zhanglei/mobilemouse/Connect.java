package com.zhanglei.mobilemouse;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Connect extends AppCompatActivity {

    Button connect;
    Button mousecon;
    Button setting;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connect);

        connect=(Button)findViewById(R.id.btnconnect);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Connect.this,Wifi_connecct.class);
                startActivity(i);
            }
        });

        mousecon=(Button)findViewById(R.id.btnmouse);
        mousecon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Connect.this,MainActivity.class);
                startActivity(i);
            }
        });

        setting=(Button)findViewById(R.id.btnsetting);
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent i=new Intent(Connect.this,Setting.class);
            }
        });
    }
}
