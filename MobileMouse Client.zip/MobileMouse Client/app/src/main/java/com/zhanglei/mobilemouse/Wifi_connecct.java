package com.zhanglei.mobilemouse;

import android.content.Intent;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Wifi_connecct extends AppCompatActivity {

    Button Wifi;
    Button IP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wifi_connecct);

        Wifi=(Button) findViewById(R.id.btnwifi);
        Wifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK));
            }
        });


        IP=(Button)findViewById(R.id.btnip);
        IP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Wifi_connecct.this,Ip_address.class);
                startActivity(i);
            }
        });
    }
}
