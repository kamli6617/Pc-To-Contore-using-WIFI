package com.zhanglei.mobilemouse;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainLogin extends AppCompatActivity {

        EditText e1,e2;
        String name,pass;
        Button login;

       DatabaseHelper dbhelper;
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main_login);

            e1 =(EditText) findViewById(R.id.edtuname);
            e2=(EditText) findViewById(R.id.edtpass);

            login=(Button)findViewById(R.id.btnlogin);

            dbhelper = new DatabaseHelper(this);

            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    name = e1.getText().toString();
                    pass = e2.getText().toString();
                    dbhelper.Inserdata(name, pass);
                }
            });

        }
}
