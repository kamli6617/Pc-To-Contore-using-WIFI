package com.zhanglei.mobilemouse;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by kmali on 22-02-2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper{

    public static String DATABASE_NAME = "BBIT";
    public static int DATABASE_VERSION = 1;

    public static String TABLE_NAME = "user_master";
    public static String TABLE_NAME2= "product_master";

    public static String FIELD1="um_id";
    public static String FIELD2="um_name";
    public static String FIELD3="um_pass";

    public static String FIELD4="pm_id";
    public static String FIELD5="pm_name";
    public static String FIELD6="pm_price";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    String query="create table"+TABLE_NAME+"("+FIELD1+" integer primary key autoincreme,"+FIELD2+"TEXT, "+FIELD3+"Text )";
    sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public void Inserdata (String name , String pass){

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(FIELD2, name);
        cv.put(FIELD3, pass);
        DB.insert(TABLE_NAME,null,cv);
    }
}
